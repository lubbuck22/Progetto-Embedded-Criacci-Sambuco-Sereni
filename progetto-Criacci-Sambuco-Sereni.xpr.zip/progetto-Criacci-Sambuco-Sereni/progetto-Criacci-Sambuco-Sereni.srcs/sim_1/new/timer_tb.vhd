library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.custom_types.all;

entity timer_tb is
end timer_tb;

architecture Behavioral of timer_tb is
    component project_main_tb is
    Port (
    clk_in1: in std_logic;
    reset: in std_logic;
    btnU, btnD, btnL, btnR, btnC: in std_logic;
    seg: out std_logic_vector(6 downto 0);
    dp: out std_logic;
    an: out std_logic_vector(3 downto 0);
    led: out std_logic_vector (15 downto 0);
    buzzer_out: out std_logic;
    numbers_to_display: out digit_array(3 downto 0);
    state: out state_type);
end component;

    signal clk_in1: std_logic := '0';
    signal reset: std_logic := '0';
    signal btnU, btnD, btnL, btnR, btnC: std_logic := '0';
    signal seg: std_logic_vector(6 downto 0);
    signal dp: std_logic;
    signal an: std_logic_vector(3 downto 0);
    signal led: std_logic_vector (15 downto 0);
    signal buzzer_out: std_logic;
    signal numbers_to_display: digit_array(3 downto 0);
    signal state: state_type;

    constant clk1_period : time := 10 ns;
    constant click_time : time := 250 us;

begin

    MAIN_INST : project_main_tb
        Port map (
        clk_in1 => clk_in1,
        reset => reset,
        btnU => btnU,
        btnD => btnD,
        btnL => btnL,
        btnR => btnR,
        btnC => btnC,
        seg => seg,
        dp => dp,
        an => an,
        led => led,
        buzzer_out => buzzer_out,
        numbers_to_display => numbers_to_display,
        state => state
        );
    
    -- definizione del clock
    clk_process: process
    begin
        wait for clk1_period/2; clk_in1 <= not clk_in1;
    end process;

    -- simulazione
    stim_proc: process
    begin
        
        wait for 10 ms;

        -- test: transizioni di stato
        btnL <= '1', '0' after click_time;  -- CRON_RESET -> TIMER_RESET
        wait for 5 ms;
        btnU <= '1', '0' after click_time;  -- TIMER_RESET -> TIMER_SET (00:00)
        wait for 5 ms;
        btnR <= '1', '0' after click_time;  -- TIMER_SET -> TIMER_COUNTDOWN
        wait for 5 ms;
        btnD <= '1', '0' after click_time;  -- TIMER_COUNTDOWN -> TIMER_RESET (sovrascrive la fine del countdown)
        wait for 5 ms;
        btnR <= '1', '0' after click_time;  -- TIMER_RESET -> TIMER_COUNTDOWN -> TIMER_BEEP
        wait for 15 ms;
        btnR <= '1', '0' after click_time;  -- TIMER_BEEP -> TIMER_RESET
        wait for 5 ms;
        btnC <= '1', '0' after click_time;  -- TIMER_RESET -> TIMER_SET (00:00)
        wait for 5 ms;
        btnR <= '1', '0' after click_time;  -- TIMER_SET -> TIMER_COUNTDOWN
        wait for 10 ms;
        btnR <= '1', '0' after click_time;  -- TIMER_COUNTDOWN -> TIMER_STOP
        wait for 10 ms; -- 75 ms
        -- verificando che lo stato di BEEP non venga anticipato, si testa la precisione di conteggio
        
        
        btnD <= '1', '0' after click_time;  -- TIMER_STOP -> TIMER_RESET
        
        wait for 5 ms;
        btnL <= '1', '0' after click_time;  -- TIMER_RESET -> WATCH
        wait for 5 ms;
        btnL <= '1', '0' after click_time;  -- WATCH -> CRON_RESET
        wait for 5 ms;
        btnL <= '1', '0' after click_time;  -- CRON_RESET -> TIMER_RESET
        wait for 5 ms;
        -- 95 ms;
        
        
        btnU <= '1', '0' after click_time;  -- TIMER_RESET -> TIMER_SET (00:00)
        -- Set to 01:02 but press minutes 101 times and seconds 62 times to test limits
        -- in questo modo si verifica il corretto aggiornamento del display
        for i in 0 to  100 loop
            wait for 2 * click_time;
            btnU <= '1', '0' after click_time;
        end loop;

        for i in 0 to  61 loop
            wait for 2 * click_time;
            btnC <= '1', '0' after click_time;
        end loop;

    end process;

end Behavioral;