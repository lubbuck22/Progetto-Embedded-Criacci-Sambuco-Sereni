library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.custom_types.all;

entity cron_tb is
end cron_tb;

architecture Behavioral of cron_tb is
    component project_main_tb is
    Port (
    clk_in1: in std_logic;
    reset: in std_logic;
    btnU, btnD, btnL, btnR, btnC: in std_logic;
    seg: out std_logic_vector(6 downto 0);
    dp: out std_logic;
    an: out std_logic_vector(3 downto 0);
    led: out std_logic_vector (15 downto 0);
    buzzer_out: out std_logic;
    numbers_to_display: out digit_array(3 downto 0);
    state: out state_type);
end component;

    signal clk_in1: std_logic := '0';
    signal reset: std_logic := '0';
    signal btnU, btnD, btnL, btnR, btnC: std_logic := '0';
    signal seg: std_logic_vector(6 downto 0);
    signal dp: std_logic;
    signal an: std_logic_vector(3 downto 0);
    signal led: std_logic_vector (15 downto 0);
    signal buzzer_out: std_logic;
    signal numbers_to_display: digit_array(3 downto 0);
    signal state: state_type;

    constant clk1_period : time := 10 ns;
    constant click_time : time := 1 ms;
begin

    MAIN_INST : project_main_tb
        Port map (
        clk_in1 => clk_in1,
        reset => reset,
        btnU => btnU,
        btnD => btnD,
        btnL => btnL,
        btnR => btnR,
        btnC => btnC,
        seg => seg,
        dp => dp,
        an => an,
        led => led,
        buzzer_out => buzzer_out,
        numbers_to_display => numbers_to_display,
        state => state
        );

    -- Definizione del segnale di clk
    clk_process :process
    begin
        wait for clk1_period/2; clk_in1 <= not clk_in1;
    end process;

    -- Simulazione
    stim_proc: process
    begin        
        -- attendiamo 10 ms
        wait for 10 ms;

        -- Testiamo le transizioni 
        btnR <= '1', '0' after click_time; -- CRON_RESET -> CRON_COUNT
        wait for 5 ms;
        btnR <= '1', '0' after click_time; --CRON_COUNT -> CRON_STOP
        wait for 5 ms;
        btnD <= '1', '0' after click_time;  --CRON_STOP -> CRON_RESET
        wait for 5 ms;
        btnR <= '1', '0' after click_time;  -- CRON_RESET -> CRON_COUNT
        wait for 5 ms;
        btnD <= '1', '0' after click_time;  -- CRON_COUNT -> CRON_RESET
        wait for 10 ms;
        
        -- Siamo adesso a 45 ms
        
        -- Testiamo la precisione
        -- Se fermiamo il cronometro a met� di un conteggio perdiamo di precisione?
        btnR <= '1', '0' after click_time;  -- Parte il cronometro
        wait for 13 ms;
        btnR <= '1', '0' after click_time;  -- Si ferma il cronometro
        wait for 5 ms;
        btnR <= '1', '0' after click_time; -- Riparte il cronometro
        wait for 7 ms; -- Al 65 ms il cronometro dovrebbe rappresentare 00:02
        
        -- Proviamo a cliccare tutti i pulsanti insieme
        wait for 5 ms;
        btnL <= '1', '0' after click_time;
        btnR <= '1', '0' after click_time; -- Solo questo avr� effetto, CRON_COUNT -> CRON_STOP
        btnU <= '1', '0' after click_time;
        btnD <= '1', '0' after click_time;
        btnC <= '1', '0' after click_time;
        wait for 5 ms;
        btnD <= '1', '0' after click_time; -- RESET
        wait for 5 ms; -- 80 ms
        
        -- Proviamo a cliccare il tasto Down, mentre teniamo premuto il tasto Right
        btnR <= '1', '0' after 20 ms;
        wait for 5 ms;
        btnD <= '1', '0' after click_time;
        wait for 25 ms; -- 110 ms
        -- Controlliamo che la conversione secondi -> minuti funzioni correttamente
        btnR <= '1', '0' after click_time; -- CRON_RESET -> CRON_COUNT
        wait for 1 sec;
        wait for 10 ms;
        btnR <= '1', '0' after click_time; -- CRON_COUNT -> CRON_STOP
        -- 1120 ms
        
    end process;

end Behavioral;
        