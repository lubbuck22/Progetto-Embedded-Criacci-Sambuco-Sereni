library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity clk_watch_divider is
  Port (clk_in : in STD_LOGIC;
        locked : in STD_LOGIC;
        clk_out : out STD_LOGIC);
end clk_watch_divider;
architecture Behavioral of clk_watch_divider is
    signal counter: unsigned(27 downto 0) := (others => '0'); --integer := 0; -- 28 bit counter per contare fino a 150000000
    constant convertion_rate: unsigned(27 downto 0) := TO_UNSIGNED(150000000, 28); -- integer := 150000000; -- 5MHz / 100Hz / 2
    signal clk_internal: std_logic := '1';
begin

    process(clk_in)
    begin
        if rising_edge(clk_in) then
            if locked = '1' then
                if counter >= convertion_rate - 1 then
                    clk_internal <= not clk_internal;
                    counter <= (others => '0');
                else
                    counter <= counter + 1;
                end if;
            end if;
        end if;
    end process;
    
    clk_out <= clk_internal;
    

end Behavioral;