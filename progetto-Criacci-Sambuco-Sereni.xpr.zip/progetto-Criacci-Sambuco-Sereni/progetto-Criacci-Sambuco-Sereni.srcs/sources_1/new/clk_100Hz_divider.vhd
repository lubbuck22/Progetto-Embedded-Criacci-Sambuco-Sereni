library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity clk_100Hz_divider is
  Port (clk_in : in STD_LOGIC;
        locked : in STD_LOGIC;
        enable : in STD_LOGIC;
        reset : in STD_LOGIC;
        clk_out : out STD_LOGIC);
end clk_100Hz_divider;

architecture Behavioral of clk_100Hz_divider is
    signal counter: unsigned(14 downto 0) := (others => '0'); --integer := 0; -- 15 bit counter per contare fino a 25000
    constant convertion_rate: unsigned(14 downto 0) := TO_UNSIGNED(25000, 15); --integer := 25000; -- 5MHz / 100Hz / 2
    signal clk_internal: std_logic := '1';
begin

    process(clk_in, reset)
    begin
        if reset = '1' then
            counter <= (others => '0');
            clk_internal <= '1';
        elsif rising_edge(clk_in) then
            if locked = '1' and enable = '1' then         
                if counter >= convertion_rate - 1 then
                    clk_internal <= not clk_internal;
                    counter <= (others => '0');
                else
                    counter <= counter + 1;
                end if;
            end if;
        end if;
    end process;
    
    clk_out <= clk_internal;
    

end Behavioral;