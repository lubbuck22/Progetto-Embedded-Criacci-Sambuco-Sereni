library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity music_player is
    Port ( 
        clk    : in  STD_LOGIC; -- Clock a 5 MHz
        locked: in std_logic;
        enable: in std_logic;
        buzzer : out STD_LOGIC  -- Uscita per il buzzer
    );
end music_player;

architecture Behavioral of music_player is
    signal counter: integer :=0;
    signal buzzer_state: std_logic :='0';
begin

process(clk)
begin
    if rising_edge(clk) then
        if locked = '1' then
            buzzer <= buzzer_state;
            -- Conta il tempo per il ritmo (es. Beep ogni secondo)
            if counter < 1250000 and enable = '1' then  -- Primo 1/4 di secondo
                buzzer_state <= '1';        -- ACCESO (Fisso a 1)
            else
                buzzer_state <= '0';        -- SPENTO
            end if;
            
            -- Reset del contatore ogni secondo (5.000.000)
            if counter >= 5000000 then
                counter <= 0;
            else
                counter <= counter + 1;
            end if;
        end if;
    end if;
end process;

end Behavioral;