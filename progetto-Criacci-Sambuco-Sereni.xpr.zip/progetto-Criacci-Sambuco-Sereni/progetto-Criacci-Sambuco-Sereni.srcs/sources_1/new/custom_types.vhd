library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

package custom_types is
    type state_type is (CRON_RESET, CRON_COUNT, CRON_STOP, TIMER_RESET, TIMER_SET, TIMER_COUNTDOWN, TIMER_STOP, TIMER_BEEP, WATCH); -- Sostituiamo con gli stati del nostro progetto
    type digit_array is array (natural range <>) of integer range 0 to 9;
end package custom_types;