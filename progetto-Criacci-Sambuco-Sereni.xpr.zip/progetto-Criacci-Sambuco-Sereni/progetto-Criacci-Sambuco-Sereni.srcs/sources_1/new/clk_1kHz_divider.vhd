library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity clk_1kHz_divider is
  Port (clk_in : in STD_LOGIC; -- clock di ingresso a 5MHz
        locked : in STD_LOGIC; -- segnale di controllo
        clk_out : out STD_LOGIC); -- clock di uscita a 1kHz
end clk_1kHz_divider;

architecture Behavioral of clk_1kHz_divider is
    signal counter: unsigned(11 downto 0) := (others => '0'); -- Contatore a 13 bit per contare fino a 2500
    constant convertion_rate: unsigned(11 downto 0) := TO_UNSIGNED(2500, 12); -- 5MHz / (1kHz * 2)
    signal clk_internal: std_logic := '1';

begin

    process(clk_in)
    begin
        if rising_edge(clk_in) then
            if locked = '1' then -- se il segnale di controllo è attivo si attiva il conteggio       
                if counter >= convertion_rate - 1 then -- se il contatore raggiunge il valore di conversione
                    clk_internal <= not clk_internal; -- inverto il clock interno
                    counter <= (others => '0'); -- azzero il contatore
                else
                    counter <= counter + 1; -- incremento del contatore a ogni ciclo di clock
                end if;
            end if;
        end if;
    end process;
    
    clk_out <= clk_internal;


end Behavioral;

