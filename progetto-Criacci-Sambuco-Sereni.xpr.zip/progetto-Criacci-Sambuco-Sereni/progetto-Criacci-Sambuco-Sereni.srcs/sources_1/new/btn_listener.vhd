library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity btn_listener is
  Port (clk_5MHz, locked: in std_logic;
        btnL, btnR, btnU, btnD, btnC: in std_logic;
        pressed_btnL, pressed_btnR, pressed_btnU, pressed_btnD, pressed_btnC: out std_logic);
end btn_listener;

architecture Behavioral of btn_listener is
    signal prev_btnL, prev_btnR, prev_btnU, prev_btnD, prev_btnC: std_logic := '0';
begin
process(clk_5MHz)
    begin
        if rising_edge(clk_5MHz) then
            if locked = '1' then
                
                pressed_btnL <= not(prev_btnL) and btnL;
                pressed_btnR <= not(prev_btnR) and btnR;
                pressed_btnU <= not(prev_btnU) and btnU;
                pressed_btnD <= not(prev_btnD) and btnD;
                pressed_btnC <= not(prev_btnC) and btnC;
    
                -- Aggiorna lo stato precedente dei bottoni
                prev_btnU <= btnU;
                prev_btnD <= btnD;
                prev_btnL <= btnL;
                prev_btnR <= btnR;
                prev_btnC <= btnC;
               
            end if;          
        end if; 
    end process;


end Behavioral;
