library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.numeric_std.all;
use work.custom_types.all;

entity display_7seg is
    Port ( clk           : in  STD_LOGIC; -- segnale di clock
           locked        : in  STD_LOGIC; -- indica che il clock � stabile (uscita del clk wizard)
           numbers       : in  digit_array(3 downto 0); -- numeri in decimale da visualizzare
           current_state : in  state_type; -- stato corrente del sistema
           seg           : out STD_LOGIC_VECTOR (6 downto 0); -- vettore dei 7 segmenti
           an            : out STD_LOGIC_VECTOR (3 downto 0); -- anodi dei 4 display
           dp            : out STD_LOGIC -- punto decimale
    );
end display_7seg;

architecture Behavioral of display_7seg is
    
    signal clk_1kHz: std_logic := '0';
    signal active_index : unsigned(1 downto 0) := (others => '0'); -- Indice del display attivo
    
    Component clk_1kHz_divider
        Port(clk_in: in std_logic;
            locked: in std_logic;
            clk_out: out std_logic);
        
   End component;
begin

    U1_0: clk_1kHz_divider port map(
        clk_in => clk,
        locked => locked,
        clk_out => clk_1kHz
    );


    process(clk_1kHz)
        variable digit : integer;
        variable counter: unsigned(9 downto 0) := (others => '0');

    begin
        if rising_edge(clk_1kHz) then
            if locked = '1' then
                
                counter := (counter + 1) mod 1000;
                
                if current_state = CRON_RESET then
                        -- Se siamo nello stato di cronometro reset e tutti i numeri sono zero, visualizzo 'c'
                        active_index <= (others => '0');
                        an           <= "1110";
                        seg          <= "0100111";   -- Visualizza 'c'
                        dp           <= '1';         -- Spegne il punto decimale
                 elsif current_state = TIMER_RESET then
                        -- Se siamo nello stato di timer reset e tutti i numeri sono zero, visualizzo 't'
                        active_index <= (others => '0');
                        an           <= "1110";
                        seg          <= "0000111";   -- Visualizza 't'
                        dp           <= '1';         -- Spegne il punto decimale
                 elsif counter < 500 and (current_state = CRON_STOP or current_state = TIMER_STOP or current_state = TIMER_BEEP) then
                    an    <= "1111";      -- Disattiva tutti i display
                    digit := 0;
                    dp <= '1';
                         
                 else
                        if active_index < 3 then
                            active_index <= active_index +1;
                        else
                            active_index <= (others => '0');
                        end if;
                        
                        case active_index is
                            when "00" =>
                                an    <= "1110";      -- Attiva il primo display
                                digit := numbers(0);
                                dp <= '1'; -- Punto spento sul primo display
                            when "01" =>
                                an    <= "1101";      -- Attiva il secondo display
                                digit := numbers(1);
                                dp <= '1'; -- Punto spento sul secondo display
                            when "10" =>
                                an    <= "1011";      -- Attiva il terzo display
                                digit := numbers(2);
                                dp <= '0'; -- Punto acceso sul terzo display
                            when "11" =>
                                an    <= "0111";      -- Attiva il quarto display
                                digit := numbers(3);
                                dp <= '1'; -- Punto spento sul quarto display
                            when others =>
                                an    <= "1111";      -- Disattiva tutti i display
                                digit := 0;
                                dp <= '1';            -- Punto spento
                        end case;
                        
                        -- Se siamo in TIMER_BEEP il display rappresenta "BEEP"
                        if current_state = TIMER_BEEP then
                            case active_index is
                                when "00" => seg <= "0001100";
                                when "01" => seg <= "0000110";
                                when "10" => seg <= "0000110";
                                when "11" => seg <= "0000000";

                                when others => seg <= "1111111";
                            end case;
                            dp <= '1';
                        else
                        --Altrimenti effetuiamo laDecodifica dei Segmenti
                            case digit is
                                when 0 => seg <= "1000000";
                                when 1 => seg <= "1111001";
                                when 2 => seg <= "0100100";
                                when 3 => seg <= "0110000";
                                when 4 => seg <= "0011001";
                                when 5 => seg <= "0010010";
                                when 6 => seg <= "0000010";
                                when 7 => seg <= "1111000";
                                when 8 => seg <= "0000000";
                                when 9 => seg <= "0010000";

                                when others => seg <= "1111111"; 
                            end case;
                        end if;
                    end if;
                
            else
                -- Reset se il clock non è pronto
                active_index <= (others => '0');
                an           <= "1111";      -- Disattiva tutti i display
                seg          <= "1111111";   -- Spegne tutti i segmenti
                dp           <= '1';         -- Spegne il punto decimale
            end if;      
        end if;

    end process;

end behavioral;