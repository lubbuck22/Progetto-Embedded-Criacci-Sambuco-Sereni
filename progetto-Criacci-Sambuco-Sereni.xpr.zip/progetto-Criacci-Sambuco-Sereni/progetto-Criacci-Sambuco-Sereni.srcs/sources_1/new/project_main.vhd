library IEEE;
use IEEE.std_logic_1164.ALL;
use work.custom_types.all;

entity project_main is
Port (
    clk_in1: in std_logic;
    reset: in std_logic;
    btnU, btnD, btnL, btnR, btnC: in std_logic;
    seg: out std_logic_vector(6 downto 0);
    dp: out std_logic;
    an: out std_logic_vector(3 downto 0);
    led: out std_logic_vector (15 downto 0);
    buzzer_out: out std_logic);
end project_main;

architecture Struct of project_main is

    signal current_state: state_type := CRON_RESET;
    signal locked,clk_5MHz, timer_finished: std_logic := '0';
    signal pressed_btnL, pressed_btnR, pressed_btnU, pressed_btnD, pressed_btnC: std_logic := '0' ;
    signal n_to_display: digit_array(3 downto 0);

    Component clk_wiz_0
        port (clk_in1, reset: in std_logic;
            locked,clk_out1: out std_logic);
    End Component;
    
    
    Component display_7seg 
        port (clk           : in  STD_LOGIC;
           locked        : in  STD_LOGIC; 
           numbers       : in  digit_array(3 downto 0);
           current_state : in  state_type; 
           seg           : out STD_LOGIC_VECTOR (6 downto 0); 
           an            : out STD_LOGIC_VECTOR (3 downto 0);
           dp            : out STD_LOGIC
           );
    End component;
    
    Component btn_listener
        port (clk_5MHz, locked: in std_logic; 
        btnL, btnR, btnU, btnD, btnC: in std_logic;
        pressed_btnL, pressed_btnR, pressed_btnU, pressed_btnD, pressed_btnC: out std_logic);
    End component;
    
    Component state_changer
        port(clk_5MHz, locked: in std_logic; 
        current_state: in state_type;
        pressed_btnL, pressed_btnR, pressed_btnU, pressed_btnD, pressed_btnC: in std_logic;
        timer_finished: in std_logic;
        next_state: out state_type);
    End component;
    
    Component state_handler is
        Port (current_state: in state_type;
        clk_5MHz, locked: in std_logic;
        timeUpLeft, timeUpRight: in std_logic;
        numbers_to_display: out digit_array(3 downto 0);
        timer_finished: out std_logic;
        led: out std_logic_vector(15 downto 0);
        buzzer: out std_logic);
    end component;    

begin
    U0: clk_wiz_0 Port map (
    clk_in1 => clk_in1,
    reset => reset,
    locked => locked,
    clk_out1 => clk_5MHz);
    

 
    U1 : display_7seg port map (
        clk=> clk_5MHz,
        locked => locked,
        numbers => n_to_display,
        current_state => current_state,
        an => an,
        seg => seg,
        dp => dp
    );

    U2: btn_listener port map(
        clk_5MHz => clk_5Mhz, 
        locked => locked,
        btnL => btnL,
        btnR => btnR,
        btnU => btnU,
        btnD => btnD,
        btnC => btnC,
        pressed_btnL => pressed_btnL,
        pressed_btnR => pressed_btnR,
        pressed_btnU => pressed_btnU,
        pressed_btnD => pressed_btnD,
        pressed_btnC => pressed_btnC
    );

    U3: state_changer port map(
        clk_5MHz => clk_5MHz,
        locked => locked,
        current_state => current_state,
        pressed_btnL => pressed_btnL,
        pressed_btnR => pressed_btnR,
        pressed_btnU => pressed_btnU,
        pressed_btnD => pressed_btnD,
        pressed_btnC => pressed_btnC,
        timer_finished => timer_finished,
        next_state => current_state
    );

    U4: state_handler port map(
        current_state => current_state,
        clk_5MHz => clk_5MHz,
        locked => locked,
        timeUpLeft => pressed_btnU,
        timeUpRight => pressed_btnC,
        numbers_to_display => n_to_display,
        timer_finished => timer_finished,
        led => led,
        buzzer => buzzer_out
    );
    
end Struct;