library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.custom_types.all;

entity state_changer is
        port(clk_5MHz, locked: in std_logic; 
        current_state: in state_type;
        pressed_btnL, pressed_btnR, pressed_btnU, pressed_btnD, pressed_btnC: in std_logic;
        timer_finished: in std_logic;
        next_state: out state_type);
end state_changer;

architecture Behavioral of state_changer is
begin
    process(clk_5MHz)
    begin
        if rising_edge(clk_5MHz) then
            if locked = '1' then
                
                case current_state is
                    when CRON_RESET =>
                        if pressed_btnR = '1' then
                            next_state <= CRON_COUNT;
                        elsif pressed_btnL = '1' then
                            next_state <= TIMER_RESET;
                        end if;
                    when CRON_COUNT =>
                        if pressed_btnR = '1' then
                            next_state <= CRON_STOP;
                        elsif pressed_btnD = '1' then
                            next_state <= CRON_RESET;
                        elsif pressed_btnL = '1' then
                            next_state <= TIMER_RESET;
                        end if;
                    when CRON_STOP =>
                        if pressed_btnR = '1' then
                            next_state <= CRON_COUNT;
                        elsif pressed_btnD = '1' then
                            next_state <= CRON_RESET;
                        elsif pressed_btnL = '1' then
                            next_state <= TIMER_RESET;
                        end if;
                    when TIMER_RESET =>
                        if pressed_btnR = '1' then
                            next_state <= TIMER_COUNTDOWN;
                        elsif pressed_btnL = '1' then
                            next_state <= WATCH;
                        elsif pressed_btnU = '1' or pressed_btnC = '1' then
                            next_state <= TIMER_SET;
                        end if;
                    when TIMER_SET =>
                        if pressed_btnR = '1' then
                            next_state <= TIMER_COUNTDOWN;
                        elsif pressed_btnD = '1' then
                            next_state <= TIMER_RESET;
                        elsif pressed_btnL = '1' then
                            next_state <= WATCH;
                        end if;
                    when TIMER_COUNTDOWN =>
                        if pressed_btnR = '1' then
                            next_state <= TIMER_STOP;
                        elsif pressed_btnD = '1' then
                            next_state <= TIMER_RESET;
                        elsif pressed_btnL = '1' then
                            next_state <= WATCH;
                        elsif timer_finished = '1' then
                            next_state <= TIMER_BEEP;
                        end if;
                    when TIMER_STOP =>
                        if pressed_btnR = '1' then
                            next_state <= TIMER_COUNTDOWN;
                        elsif pressed_btnD = '1' then
                            next_state <= TIMER_RESET;
                        elsif pressed_btnL = '1' then
                            next_state <= WATCH;
                        end if;
                    when TIMER_BEEP =>
                        if pressed_btnR = '1' or pressed_btnD = '1' then
                            next_state <= TIMER_RESET;
                        elsif pressed_btnL = '1' then
                            next_state <= WATCH;
                        end if;
                        
                     -- OROLOGIO
                     when WATCH =>
                        if pressed_btnL = '1' then
                            next_state <= CRON_RESET;
                        end if;
                end case;
            end if;
        end if;
                
    end process;


end Behavioral;