library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.custom_types.all;

entity state_handler is
  Port (current_state: in state_type;
        clk_5MHz, locked: in std_logic;
        timeUpLeft, timeUpRight: in std_logic;
        numbers_to_display: out digit_array(3 downto 0);
        timer_finished: out std_logic;
        led: out std_logic_vector(15 downto 0);
        buzzer: out std_logic);
end state_handler;

architecture Behavioral of state_handler is
    signal centiseconds, seconds, minutes, hours: integer :=0;
    signal watch_minutes, watch_hours: integer:=0;
    signal enable_clk_100Hz, reset_clk_100Hz : std_logic := '0';
    signal clk_100Hz, clk_minutes: std_logic := '0';
    signal prev_clk_100Hz, prev_clk_minutes: std_logic := '1';
    signal enable_buzzer: std_logic := '0';
   

    component clk_100Hz_divider
        port(clk_in : in STD_LOGIC;
             locked : in STD_LOGIC;
             enable : in STD_LOGIC;
             reset : in STD_LOGIC;
             clk_out : out STD_LOGIC);
    end component;
    
    component clk_watch_divider
        port(clk_in : in STD_LOGIC; 
             locked : in STD_LOGIC;
             clk_out : out STD_LOGIC);
    end component;

    component music_player
        port(clk: in std_logic;
            locked: in std_logic;
            enable: in std_logic;
            buzzer: out std_logic
            );
    end component;
    
begin

U4_0: clk_100Hz_divider port map(
    clk_in => clk_5MHz,
    locked => locked,
    enable => enable_clk_100Hz,
    reset => reset_clk_100Hz,
    clk_out => clk_100Hz);
    
U4_1: clk_watch_divider port map (
    clk_in => clk_5MHz,
    locked => locked,
    clk_out => clk_minutes);
    
U4_2: music_player port map(
    clk => clk_5MHz,
    locked => locked,
    enable => enable_buzzer,
    buzzer => buzzer);

process(clk_5MHz)
    variable temp : integer :=0;
    begin
        if rising_edge(clk_5MHz) then
            if locked = '1' then
                -- Gestione enable e reset per il clock a 100 Hz
                if current_state = CRON_COUNT or current_state = TIMER_COUNTDOWN then
                    enable_clk_100Hz <= '1';
                else
                    enable_clk_100Hz <= '0';
                end if;
                if current_state = CRON_RESET or current_state = TIMER_RESET then
                    reset_clk_100Hz <= '1';
                else
                    reset_clk_100Hz <= '0';
                end if;

                -- Gestione stati
                case current_state is

                    when CRON_RESET =>
                        -- Inizializza il cronometro a 00:00
                        centiseconds <= 0;
                        seconds <= 0;
                        minutes <= 0;

                    when CRON_COUNT =>
                        if(clk_100Hz = '1' and prev_clk_100Hz = '0') then
                            -- Incrementa il cronometro di 1 centesimo di secondo
                            centiseconds <= centiseconds + 1;
                            if centiseconds = 99 then
                                centiseconds <= 0;
                                seconds <= seconds + 1;
                                if seconds = 59 then
                                    seconds <= 0;
                                        if minutes < 17 then
                                            minutes <= minutes + 1;
                                        end if;
                                end if;
                            end if;
                        end if;

                    when CRON_STOP =>
                        null; -- Non fare nulla, il cronometro ? fermo

                    when TIMER_RESET =>
                        -- Inizializza il timer a 00:00
                        centiseconds <= 0;
                        seconds <= 0;
                        minutes <= 0;
                        enable_buzzer <= '0';
                        
                    when TIMER_SET =>
                        -- Imposta il timer in base agli input esterni
                        if timeUpRight = '1' then
                            if seconds < 59 then
                                seconds <= seconds + 1;
                            else
                                seconds <= 0;
                            end if;
                        end if;
                        if timeUpLeft = '1' then
                            if minutes < 99 then
                                minutes <= minutes + 1;
                            else
                                minutes <= 0;
                            end if;
                        end if;

                    when TIMER_COUNTDOWN =>
                        if(clk_100Hz = '1' and prev_clk_100Hz = '0') then
                            -- Decrementa il timer di 1 centesimo di secondo
                            if centiseconds = 0 then
                                if seconds = 0 then
                                    if minutes = 0 then
                                        -- Timer finito
                                        timer_finished <= '1';
                                    else
                                        minutes <= minutes - 1;
                                        seconds <= 59;
                                        centiseconds <= 99;
                                    end if;
                                else
                                    seconds <= seconds - 1;
                                    centiseconds <= 99;
                                end if;
                            else
                                centiseconds <= centiseconds - 1;
                            end if;
                        end if;

                    when TIMER_STOP =>
                        null; -- Non fare nulla, il timer ? fermo

                    when TIMER_BEEP =>
                        timer_finished <= '0'; -- Riporta a zero il segnale di fine timer
                        enable_buzzer <= '1';
                        
                    -- OROLOGIO
                    when WATCH =>
                        if timeUpRight = '1' then
                            if watch_minutes < 59 then
                                watch_minutes <= watch_minutes + 1;
                            else
                                watch_minutes <= 0;
                            end if;
                        end if;
                        if timeUpLeft = '1' then
                            if watch_hours < 23 then
                                watch_hours <= watch_hours + 1;
                            else
                                watch_hours <= 0;
                            end if;
                        end if;   
                        enable_buzzer <= '0';      
                end case;
               
                if(clk_minutes = '1' and prev_clk_minutes = '0') then
                    -- Incremento dell'orologio
                    watch_minutes <= watch_minutes + 1;
                    if watch_minutes = 59 then
                        watch_minutes <= 0;
                        watch_hours <= watch_hours + 1;
                        if watch_hours = 23 then
                           watch_hours <= 0;
                        end if;
                    end if;
                end if;
                
                case current_state is
                    when CRON_RESET | CRON_COUNT | CRON_STOP =>

                        -- Aggiorna i centisecondi da visualizzare sul display
                        temp := centiseconds mod 10;
                        numbers_to_display(0) <= temp;
                        temp := (centiseconds - temp)/10;
                        numbers_to_display(1) <= temp;
                        
                        -- Aggiorna i secondi da visualizzare sul display
                        temp := seconds mod 10;
                        numbers_to_display(2) <= temp;
                        temp := (seconds - temp)/10;
                        numbers_to_display(3) <= temp;

                        -- Accendi i primi minutes LED
                        led <= (others => '0');
                        for i in 0 to 15 loop
                            if i < minutes then
                                led(i) <= '1';
                            end if;
                        end loop;
                        
                    when TIMER_RESET | TIMER_SET | TIMER_COUNTDOWN | TIMER_STOP | TIMER_BEEP =>
                        temp := seconds mod 10;
                        numbers_to_display(0) <= temp;
                        temp := (seconds - temp)/10;
                        numbers_to_display(1) <= temp;
                        
                        temp := minutes mod 10;
                        numbers_to_display(2) <= temp;
                        temp := (minutes - temp)/10;
                        numbers_to_display(3) <= temp;
                        
                        if current_state = TIMER_BEEP then
                            led <= (others => '1');
                        else
                            led <= (others => '0');
                        end if;
                    when WATCH =>
                        temp := watch_minutes mod 10;
                        numbers_to_display(0) <= temp;
                        temp := (watch_minutes - temp)/10;
                        numbers_to_display(1) <= temp;
                        
                        temp := watch_hours mod 10;
                        numbers_to_display(2) <= temp;
                        temp := (watch_hours - temp)/10;
                        numbers_to_display(3) <= temp;
                        led <= (others => '0');
                end case;
            prev_clk_100Hz <= clk_100Hz;
            prev_clk_minutes <= clk_minutes;
            end if;          
        end if; 
    end process;
end Behavioral;